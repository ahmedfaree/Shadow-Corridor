package com.shadowcorridor.game;
import android.app.Activity; import android.os.Bundle; import android.webkit.WebView; import android.webkit.WebViewClient; import android.view.WindowManager;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
 WebView w=new WebView(this); w.setBackgroundColor(0xFF08090D); w.getSettings().setJavaScriptEnabled(true); w.setWebViewClient(new WebViewClient()); setContentView(w); w.loadUrl("file:///android_asset/index.html"); }
}
